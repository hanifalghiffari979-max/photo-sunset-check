"""Check whether the time shown on a photo is plausible for a given date and place.

A demonstration tool: it shows how a time-zone assumption can flip a conclusion.
It does not prove a photo is real or fake.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from zoneinfo import ZoneInfo

from astral import Observer
from astral.sun import elevation, sun

SUNSET_THRESHOLD = -0.833   # degrees: upper limb of the sun at the horizon, incl. refraction
TWILIGHT_THRESHOLD = -6.0   # degrees: end of civil twilight


@dataclass
class Result:
    scenario: str
    time_utc: datetime
    elevation: float
    status: str


def status_from_elevation(e: float) -> str:
    if e >= SUNSET_THRESHOLD:
        return "BEFORE SUNSET"
    if e >= TWILIGHT_THRESHOLD:
        return "TWILIGHT"
    return "DARK"


def analyse(day: date, clock: str, lat: float, lon: float,
            zone: str = "America/Mexico_City", altitude_m: float = 0.0):
    """Return (sun_info, list of Result) for one date and camera time."""
    h, m = map(int, clock.split(":"))
    tz = ZoneInfo(zone)
    obs = Observer(latitude=lat, longitude=lon, elevation=altitude_m)
    s = sun(obs, date=day, tzinfo=tz)

    def fixed(minutes: int) -> datetime:
        return datetime(day.year, day.month, day.day, h, m,
                        tzinfo=timezone(timedelta(minutes=minutes)))

    local = datetime(day.year, day.month, day.day, h, m, tzinfo=tz)
    offset_min = int(local.utcoffset().total_seconds() // 60)
    candidates = [
        (f"Local zone time (rules of {day.year}, UTC{offset_min/60:+g})", local),
        ("Assumed fixed UTC-6", fixed(-360)),
        ("Assumed fixed UTC-5", fixed(-300)),
        ("Camera set to UTC", fixed(0)),
    ]
    results = []
    for name, when in candidates:
        e = elevation(obs, when)
        results.append(Result(name, when.astimezone(timezone.utc), e, status_from_elevation(e)))
    info = {"sunset": s["sunset"], "dusk": s["dusk"], "offset": local.utcoffset()}
    return info, results


def show(day: date, clock: str, lat: float, lon: float, zone: str, altitude_m: float):
    info, results = analyse(day, clock, lat, lon, zone, altitude_m)
    print(f"\n== {day.isoformat()} camera time {clock} ==")
    print(f"sunset {info['sunset']:%H:%M:%S} | twilight ends {info['dusk']:%H:%M:%S} (wall clock {zone})")
    for r in results:
        print(f"  - {r.scenario:<58} {r.time_utc:%H:%M} UTC  elevation {r.elevation:6.1f}  {r.status}")
    return results


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--lat", type=float, default=19.87)
    p.add_argument("--lon", type=float, default=-101.92)
    p.add_argument("--altitude", type=float, default=0.0, help="site altitude (m)")
    p.add_argument("--zone", default="America/Mexico_City")
    p.add_argument("--date", default="2013-10-12", help="YYYY-MM-DD")
    p.add_argument("--compare-year", type=int, default=2026)
    p.add_argument("--time", default="18:38", help="HH:MM as shown by the camera")
    a = p.parse_args()
    d1 = date.fromisoformat(a.date)
    d2 = d1.replace(year=a.compare_year)
    r1 = show(d1, a.time, a.lat, a.lon, a.zone, a.altitude)
    r2 = show(d2, a.time, a.lat, a.lon, a.zone, a.altitude)
    if r1[0].status != r2[0].status:
        print(f"\nVerdict flips: {d1.year} -> {r1[0].status}, {d2.year} -> {r2[0].status}.")
        print("Same camera time and place; only the time-zone rules changed.")
    else:
        print(f"\nSame verdict in both years ({r1[0].status}).")


if __name__ == "__main__":
    main()
