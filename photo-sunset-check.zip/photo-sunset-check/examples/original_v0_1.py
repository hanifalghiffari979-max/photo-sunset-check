# Original v0.1, kept as a baseline. Known issues: two-state verdict ("MUSTAHIL" =
# "impossible" is too strong), minute-level comparison, ignores twilight and altitude.
from datetime import date
from zoneinfo import ZoneInfo
from astral import LocationInfo
from astral.sun import sun

PLACE = LocationInfo("Tangamandapio", "MX", "America/Mexico_City", 19.87, -101.92)
CAMERA_MINUTES = 18 * 60 + 38          # minutes since midnight

for year in (2013, 2026):
    tz = ZoneInfo(PLACE.timezone)
    s = sun(PLACE.observer, date=date(year, 10, 12), tzinfo=tz)
    sunset = s["sunset"].hour * 60 + s["sunset"].minute
    verdict = "PLAUSIBLE" if CAMERA_MINUTES <= sunset else "IMPOSSIBLE"
    print(year, "| offset", s["sunset"].utcoffset(), "| solar noon", s["noon"].strftime("%H:%M"),
          "| sunset", s["sunset"].strftime("%H:%M"), "|", verdict)
