from datetime import date, timedelta

from src.sunset_check import analyse, status_from_elevation

LAT, LON = 19.87, -101.92


def test_offset_changes_between_2013_and_2026():
    i13, _ = analyse(date(2013, 10, 12), "18:38", LAT, LON)
    i26, _ = analyse(date(2026, 10, 12), "18:38", LAT, LON)
    assert i13["offset"] == timedelta(hours=-5)   # DST still in force
    assert i26["offset"] == timedelta(hours=-6)   # DST abolished in 2022


def test_wall_clock_sunset_differs_by_one_hour():
    i13, _ = analyse(date(2013, 10, 12), "18:38", LAT, LON)
    i26, _ = analyse(date(2026, 10, 12), "18:38", LAT, LON)
    diff = (i13["sunset"].hour * 60 + i13["sunset"].minute) - (i26["sunset"].hour * 60 + i26["sunset"].minute)
    assert 58 <= diff <= 62


def test_verdict_flips_for_local_time():
    _, r13 = analyse(date(2013, 10, 12), "18:38", LAT, LON)
    _, r26 = analyse(date(2026, 10, 12), "18:38", LAT, LON)
    assert r13[0].status == "BEFORE SUNSET"
    assert r26[0].status != "BEFORE SUNSET"


def test_three_statuses():
    assert status_from_elevation(10) == "BEFORE SUNSET"
    assert status_from_elevation(-3) == "TWILIGHT"
    assert status_from_elevation(-10) == "DARK"
