# Photo Sunset Check: camera time vs sunset

A small tool that answers one question: **is the time shown on a photo plausible for that date and place?**

The point is not to guess whether a photo is real. The point is to show that **one unexamined time-zone assumption can flip the conclusion** drawn from the very same file.

## Plain-language explanation

Imagine a photo stamped 18:38 in a city on 12 October. Was it still light, twilight, or already dark?

It depends on which "18:38" you mean. Some countries change their daylight-saving rules over the years. Mexico, for example, moved its clocks forward in summer until 2022 and then abolished the practice. So 18:38 in 2013 and 18:38 in 2026 at the same place are two different moments as far as the sun is concerned, one hour apart.

This tool computes the sun's position for that date and place and lines it up against the photo's time under several clock assumptions. The output is not "true" or "false". It is: **under which clock assumption is this photo plausible?**

Example result (same place and date, only the year differs):

| Year | Sunset (wall clock) | Photo time 18:38 |
|---|---|---|
| 2013 | 19:26 | Still light (sun 10° above the horizon) |
| 2026 | 18:26 | Twilight (sun 3.4° below the horizon) |

## Repository contents

| Part | Purpose |
|---|---|
| `src/sunset_check.py` | Python command-line version with three statuses: before sunset, twilight, dark |
| `gui/index.html` | Web interface: open it in a browser; it can read EXIF from a photo |
| `tests/` | Automated tests for the 2013 vs 2026 case |
| `examples/original_v0_1.py` | The original v0.1 script, kept as a baseline |
| `REPORT.md` | Report on method, results and limitations |
| `docs/sample_output.txt` | Real output from one run |
| `docs/REPORT.pdf` | PDF version of the report |

## How to run

```bash
pip install -r requirements.txt
python -m src.sunset_check
python -m src.sunset_check --lat 19.87 --lon -101.92 --date 2013-10-12 --time 18:38
python -m pytest
```

For the web interface, open `gui/index.html` in a browser. Photos are read on your device and are never uploaded.

## What this tool does NOT do

- It does not prove a photo is real or fake.
- It cannot know whether the camera clock was ever set correctly.
- The default coordinates are an assumption and must be verified before drawing any conclusion.
- EXIF brightness (EV100) is only a rough clue and is misleading for indoor or flash photos.
- EXIF is easy to edit and is often stripped by messaging apps.
- It does not yet check shadow direction and length, which is stronger evidence than the clock.

## Technology

Python 3.12, `astral` 3.2, `zoneinfo`/`tzdata`, `pytest`. The web interface uses plain JavaScript (NOAA solar-position algorithm) and `exifr` to read EXIF.

## License

MIT. See `LICENSE`.
